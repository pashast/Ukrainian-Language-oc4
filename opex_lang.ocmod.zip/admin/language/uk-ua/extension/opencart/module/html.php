<?php
// Heading
$_['heading_title'] = 'Текстовий блок (HTML)';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success']   = 'Налаштування успішно змінено!';
$_['text_edit']      = 'Налаштування модуля';

// Entry
$_['entry_name']        = 'Назва модуля';
$_['entry_title']       = 'Заголовок';
$_['entry_description'] = 'Текст';
$_['entry_status']      = 'Статус';

// Error
$_['error_permission'] = 'Увага: У Вас немає прав для керування цим модулем!';
$_['error_name']       = 'Назва модуля повинна містити від 3 до 64 символів!';
