<?php
// Heading
$_['heading_title'] = 'Самовивіз';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success']   = 'Налаштування успішно змінено!';
$_['text_edit']      = 'Редагування';

// Entry
$_['entry_geo_zone']   = 'Географічна зона';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'Увага: У Вас немає прав для керування цим модулем!';
