<?php
// Heading
$_['heading_title'] = 'Безкоштовне замовлення';

// Text
$_['text_extension'] = 'Розширення';
$_['text_success']   = 'Налаштування успішно змінено!';
$_['text_edit']      = 'Редагування';

// Entry
$_['entry_order_status'] = 'Статус замовлення';
$_['entry_status']       = 'Статус';
$_['entry_sort_order']   = 'Порядок сортування';

// Error
$_['error_permission'] = 'Увага: У Вас немає прав для керування цим модулем!';
