<?php
// Text
$_['text_footer']  = '<a href="https://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Всі права захищені.';
$_['text_version'] = 'Версія %s';