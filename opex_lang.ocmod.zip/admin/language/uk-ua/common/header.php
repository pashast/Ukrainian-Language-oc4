<?php
// Heading
$_['heading_title'] = 'Адміністрування';

// Text
$_['text_notification'] = 'Повідомлення';
$_['text_notification_all'] = 'Показати все';
$_['text_notification_none'] = 'Немає нових повідомлень';
$_['text_profile'] = 'Ваш профіль';
$_['text_store'] = 'Магазин';
$_['text_help'] = 'Допомога';
$_['text_homepage'] = 'Сайт OpenCart';
$_['text_support'] = 'Форум';
$_['text_documentation'] = 'Документація';
$_['text_logout'] = 'Вихід';