<?php
// Text
$_['text_subject'] = '%s - GDPR запит на експорт завершено!';
$_['text_request'] = 'Експорт персональних даних';
$_['text_hello'] = 'Привіт <strong>%s</strong>,';
$_['text_user'] = 'Користувач';
$_['text_gdpr'] = 'Ваш запит GDPR завершено. Нижче ви знайдете свої дані щодо GDPR.';
$_['text_account'] = 'Акаунт';
$_['text_customer'] = 'Персональна інформація';
$_['text_address'] = 'Адреса';
$_['text_addresses'] = 'Адреса';
$_['text_name'] = 'Ім\'я клієнта';
$_['text_recipient'] = 'Одержувач';
$_['text_email'] = 'E-Mail';
$_['text_telephone'] = 'Телефон';
$_['text_company'] = 'Компанія';
$_['text_address_1'] = 'Адреса 1';
$_['text_address_2'] = 'Адреса 2';
$_['text_postcode'] = 'Індекс';
$_['text_city'] = 'Місто';
$_['text_country'] = 'Країна';
$_['text_zone'] = 'Регіон';
$_['text_history'] = 'Історія входу до системи';
$_['text_ip'] = 'IP';
$_['text_date_added'] = 'Дата';
$_['text_thanks'] = 'Дякую,';