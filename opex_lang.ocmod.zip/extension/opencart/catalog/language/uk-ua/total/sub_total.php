<?php
// Text
$_['text_sub_total'] = 'Сума';