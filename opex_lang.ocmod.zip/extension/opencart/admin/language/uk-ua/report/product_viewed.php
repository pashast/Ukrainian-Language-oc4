<?php
// Heading
$_['heading_title'] = 'Перегляд товарів';

// Text
$_['text_extension'] = 'Розширення';
$_['text_edit']      = 'Редагування';
$_['text_success']   = 'Скидання звіту успішно виконано!';

// Column
$_['column_name']    = 'Назва товару';
$_['column_model']   = 'Модель';
$_['column_viewed']  = 'Переглядів';
$_['column_percent'] = 'Відсоток';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'У Вас немає прав для керування цим звітом!';
