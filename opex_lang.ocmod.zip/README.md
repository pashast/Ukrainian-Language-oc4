# Українська локалізація для OpenCart 4.0.2.2  

## Встановлення
Завантажити останній реліз [opex_lang.ocmod.zip](https://github.com/pashast/Ukrainian-Language-oc4/releases)  
Переключити адмін-панель на Англійську мову.  
У розділі Extensions/Installer встановити завнтажений архів   
У розділі Extensions/Extensions вибрати тип Languages  
Встановити і увімкнути Українську мову  

## Додаткова інформація  
Створено на основі перекладу: [https://opencartbot.com/ukrainian-opencart4](https://opencartbot.com/ukrainian-opencart4)