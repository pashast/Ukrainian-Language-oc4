<?php
// Heading
$_['heading_title'] = 'Оформлення замовлення';

// Text
$_['text_cart'] = 'Кошик покупок';