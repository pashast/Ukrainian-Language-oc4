<?php
// Heading
$_['heading_title'] = 'Файли для завантаження';

// Text
$_['text_account'] = 'Особистий Кабінет';
$_['text_downloads'] = 'Файли для завантаження';
$_['text_no_results'] = 'У Вас немає замовлень із файлами для завантаження!';

// Column
$_['column_order_id'] = '№ Замовлення';
$_['column_name'] = 'Назва';
$_['column_size'] = 'Розмір';
$_['column_date_added'] = 'Дата додавання';

// Error
$_['error_not_found'] = 'Помилка: Не вдалося знайти файл %s!';
$_['error_headers_sent'] = 'Помилка: заголовки вже надіслані!';