<?php
// Heading
$_['heading_title'] = 'Оплата при доставці';

// Error
$_['error_order_id'] = 'Немає номера замовлення в сесії!';
$_['error_payment_method'] = 'Неправильний спосіб оплати!';