<?php
// Text
$_['text_subject'] = '%s - Відгук про товар';
$_['text_waiting'] = 'Нові відгуки очікують вашої перевірки.';
$_['text_product'] = 'Товар: %s';
$_['text_reviewer'] = 'Відгук залишив: %s';
$_['text_rating'] = 'Оцінка: %s';
$_['text_review'] = 'Відгук:';