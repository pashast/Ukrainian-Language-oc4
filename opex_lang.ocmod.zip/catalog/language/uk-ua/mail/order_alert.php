<?php
// Text
$_['text_subject'] = '%s - Замовлення %s';
$_['text_received'] = 'Ви отримали замовлення.';
$_['text_order_id'] = '№ замовлення:';
$_['text_date_added'] = 'Дата замовлення:';
$_['text_order_status'] = 'Стан замовлення:';
$_['text_product'] = 'Товари';
$_['text_total'] = 'Разом';
$_['text_comment'] = 'Коментар до Вашого замовлення:';