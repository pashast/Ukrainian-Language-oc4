<?php
// Text
$_['text_success'] = 'Ваша мова успішно змінена!';

// Error
$_['error_language'] = 'Увага: Мова не знайдена!';