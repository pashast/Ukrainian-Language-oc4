<?php
// Text
$_['text_success'] = 'Магазин успішно змінено!';

// Error
$_['error_store'] = 'Увага: Магазин не знайдено!';